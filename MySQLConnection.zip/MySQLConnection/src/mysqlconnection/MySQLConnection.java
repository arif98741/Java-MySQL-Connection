package mysqlconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class MySQLConnection {

    public static void main(String[] args) {
        String url, user, pass;
        url = "jdbc:mysql://localhost:3306/testdb"; // we need a database 
        user = "root";
        pass = "";
        
        Connection con;
        
        try {
            con = DriverManager.getConnection(url, user, pass);
            JOptionPane.showMessageDialog(null, "Database Connected Sucessfully");
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, "Database not Connected "+e);
        }
    }

}
